This project state is locked as the canonical template.
Do not change layout, Pyodide loading, or Matplotlib setup.
New modules must follow page2.qmd structure.
