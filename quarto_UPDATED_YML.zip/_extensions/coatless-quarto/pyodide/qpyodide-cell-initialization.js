// Handle cell initialization initialization
qpyodideCellDetails.map(
    (entry) => {
      // Handle the creation of the element
      qpyodideCreateCell(entry);
    }
  );